﻿/* English/US initialisation for the jQuery UI date picker plugin.  This is empty because it uses the defaults */

